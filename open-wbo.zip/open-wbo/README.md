Running the partition-based algorithm on formulas with partitions:
Usage: ./open-wbo -formula=2 -algorithm=3 <formula>

Running the partition-based algorithm on formulas without partitions (the algorithm will automatically find a partition using graph-based approaches):
Usage: ./open-wbo -formula=0 -algorithm=3 <formula>

Using the same algorithm but without partitions:
Usage: ./open-wbo -formula=0 -algorithm=2 <formula>

# formula = 0 (no partition) ; formula = 2 (partitions)
# algorithm = 2 (no partition) ; algorithm = 3 (partitions)

For additional options see:
./open-wbo --help-verb
